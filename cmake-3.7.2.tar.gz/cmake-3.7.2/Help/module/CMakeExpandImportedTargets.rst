.. cmake-module:: ../../Modules/CMakeExpandImportedTargets.cmake
