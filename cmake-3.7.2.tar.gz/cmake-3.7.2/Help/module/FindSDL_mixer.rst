.. cmake-module:: ../../Modules/FindSDL_mixer.cmake
