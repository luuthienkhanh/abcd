HELPSTRING
----------

Help associated with entry in GUIs.

This string summarizes the purpose of an entry to help users set it
through a CMake GUI.
