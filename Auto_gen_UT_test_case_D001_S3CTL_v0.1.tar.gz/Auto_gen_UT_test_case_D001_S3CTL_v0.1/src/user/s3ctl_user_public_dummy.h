int open_dummy(const char *device_name, int mode_flags);
