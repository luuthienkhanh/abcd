/*
 * s3ctl_drv_dummy.h
 *
 *  Created on: Mar 21, 2016
 *      Author: AnhTran
 */

#define DEVFILE			"/dev/s3ctl"
#define DRVNAME			"s3ctl"

#define S3_IOC_MAGIC 's'
#define S3_IOC_SET_PARAM	0
#define S3_IOC_CLEAR_PARAM	1
#define S3_IOC_LOCK		2
#define S3_IOC_UNLOCK		3
#define S3_IOC_GET_PARAM	4

#define S3_MAX			(8)

#define S3_ALLOC		(1)
#define S3_FREE			(0)


#define S3_ADDR			(0xE6784000)
#define S3_SIZE			(0xD00)
#define S3_OFFSET		(0xB00)

#define S3_TL_A_EN		(0x80000000)
#define S3_TL_A_ADDR_MASK	(0x007FFFFF)
#define S3_TL_B_TILE_TYPE	(0x01000000)
#define S3_TL_B_SIZE_MASK	(0x000F0000)
#define S3_TL_B_SIZE_SHIFT	(16)
#define S3_TL_B_STRIDE_MASK	(0x00000FF0)

#define S3_XYMODE_VAL		(0x00000F00)
#define S3_XYMODE_VAL_NEW	(0x00000010)

#define S3_PRR_ADDR		(0xFF000044)
#define S3_PRR_SIZE		(4)

#define S3_PRR_ESMASK		(0x000000F0)
#define S3_PRR_ES1		(0x00000000)
#define S3_PRR_ES2		(0x00000010)
#define S3_PRR_ES3		(0x00000020)
#define S3_PRR_PRODUCTMASK	(0x00007F00)
#define S3_PRR_H2		(0x00004500)
#define S3_PRR_M2W		(0x00004700)
#define S3_PRR_M2N		(0x00004B00)
#define S3_PRR_E2		(0x00004C00)

#define S3_ST_OPEN		(0)
#define S3_ST_SET		(1)
#define S3_ST_LOCK		(2)

struct S3_XYTL {
	unsigned long	a[S3_MAX];
	unsigned long	b[S3_MAX];
	unsigned long	mode;
};

struct S3_PARAM {
	unsigned long	phy_addr;
	unsigned long	stride;
	unsigned long	area;
};

struct S3_PRIVATE {
	struct S3_PARAM	param;
	int		id;
	int		st;
};

static inline void S3_WRITE(unsigned long *reg, u32 value);
static inline u32 S3_READ(unsigned long *reg);
static int map_register(void);
static void unmap_register(void);
static void set_xymodeconf(u32 value);
static void enable_s3(int id, struct S3_PARAM *p);
static void disable_s3(int id);
static int alloc_id(int *id);
static void free_id(int *id);
static int check_param(struct S3_PARAM *p);

