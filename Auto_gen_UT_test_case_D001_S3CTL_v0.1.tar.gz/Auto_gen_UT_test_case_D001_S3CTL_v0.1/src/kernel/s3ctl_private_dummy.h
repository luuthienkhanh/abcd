/*
 * s3ctl_drv_dummy.h
 *
 *  Created on: Mar 21, 2016
 *      Author: AnhTran
 */


typedef unsigned int u32;
typedef struct spinlock {
        int raw_spinlock;
} spinlock_t;

struct file {
        void *private_data;
};

struct inode {
        int   i_lock;
};

typedef struct miscdevice {
        int minor;
        const char *name;
        const struct file_operations *fops;
} miscdevice;

struct file_operations {
        struct module *owner;
        int (*open) (struct inode *, struct file *);
        int (*release) (struct inode *, struct file *);
        long (*unlocked_ioctl) (struct file *, unsigned int, unsigned long);
};

#define THIS_MODULE ((void *)0)
#define MISC_DYNAMIC_MINOR      255
#define GFP_KERNEL      0
#define O_RDWR      0x0002
#define NULL ( (void *) 0)
#define EBUSY           16      /* Device or resource busy */
#define EFAULT          14      /* Bad address */
#define EINVAL          22      /* Invalid argument */
#define EPERM            1      /* Operation not permitted */
#define __user
typedef	int	S3CTL_ID;

//struct S3_XYTL {
//        unsigned long   a[S3_MAX];
//        unsigned long   b[S3_MAX];
//        unsigned long   mode;
//};

#define R_S3_OK		0
#define R_S3_FATAL	-1
#define R_S3_SEQE	-2
#define R_S3_PARE	-3
#define R_S3_BUSY	-4

#define S3_STRIDE_128	128
#define S3_STRIDE_256	256
#define S3_STRIDE_512	512
#define S3_STRIDE_1K	1024
#define S3_STRIDE_2K	2048
#define S3_STRIDE_4K	4096

#define S3_AREA_256	0
#define S3_AREA_512	1
#define S3_AREA_1K	2
#define S3_AREA_2K	3
#define S3_AREA_4K	4
#define S3_AREA_8K	5
#define S3_AREA_16K	6
#define S3_AREA_32K	7
#define S3_AREA_64K	8
#define S3_AREA_128K	9
#define S3_AREA_256K	10
