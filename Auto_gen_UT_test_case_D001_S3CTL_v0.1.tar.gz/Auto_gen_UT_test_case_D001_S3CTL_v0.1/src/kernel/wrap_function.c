#include <stdarg.h>
#include <stdint.h>
#include <stddef.h>
#include <setjmp.h>
#include <cmocka.h>
#include <errno.h>
//Lib dummy
int __wrap_open_dummy(const char *device_name, int mode_flags)
{
        return mock_type(int);
}

//Driver dummy
int __wrap_request_mem_region(void)
{
        return mock_type(int);
}

int __wrap_ioremap_nocache(void)
{
        return mock_type(int);
}

int __wrap_release_mem_region(void)
{
        return mock_type(int);
}

unsigned int __wrap_ioread32(void)
{
      return mock_type(unsigned int);
}

int __wrap_writel(void)
{
      return mock_type(int);
}

//int __wrap_readl(void)
//{
//      return mock_type(int);
//}

int __wrap_misc_register(void)
{
      return mock_type(int);
}

int __wrap_spin_lock_init(void)
{
      return mock_type(int);
}

int __wrap_misc_deregister(void)
{
      return mock_type(int);
}

int __wrap_iounmap(void)
{
      return mock_type(int);
}

void __wrap_kzalloc(void)
{
        return mock_type(void);
}

void __wrap_kfree(void)
{
        return mock_type(void);
}

void __wrap_spin_lock(void)
{
        return mock_type(void);
}

void __wrap_spin_unlock(void)
{
        return mock_type(void);
}

int __wrap_copy_from_user(void)
{
        return mock_type(int);
}

int __wrap_copy_to_user(void)
{
        return mock_type(int);
}




