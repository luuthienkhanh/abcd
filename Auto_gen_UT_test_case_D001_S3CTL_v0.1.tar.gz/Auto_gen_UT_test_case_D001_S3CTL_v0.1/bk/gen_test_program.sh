#!/bin/sh -f
#Note: This program run on Linux
#Function: 
#	1: Auto making UT test program base on PCL
#How_to_run: gen_test_program.sh <PCL_excel_file>
#Writen: RVC/AnhTran"
#Project: CIP
#Version: 01 First created
rm -rf tmp finish 
clear
touch ./running
echo "================================="
echo "How_to_run:"
echo "gen_test_program.sh <PCL_excel_file_name>"
echo "================================="
echo ""
#=================Input===============#
#pcl_file_name==${1}
pcl_file_name="PCL/RZG_UT_BSP_PCL__D001__S3CTL__v01r01.xls"
current_dir=`pwd`
xls2csv=/media/sf_Share/Project_CIP/Auto_tool_local/Auto_gen_UT_test_case_D001_S3CTL_v0.1/script/perl_tool/xls2csv-1.06/script/xls2csv
#=================Excel_to_csv===============#
#Check perl lib
perl_lib=`egrep "use lib" $xls2csv | egrep -v "^#"| awk -F'"' '{print $2}'`
if [ ! -d $perl_lib ]
then
	echo "Error: Path $perl_lib dont exist. Please correct file $xls2csv"
	exit 0
else
	path_lib=`egrep -w "use lib" $xls2csv | awk '{print $3}' | sed -e 's/"//g' -e 's/;.*//g'`
	if [ ! -d $path_lib ]
	then
		echo "Error: Don't exit $path_lib"
		echo "Please correct file $xls2csv again."
		exit 0
	fi
fi
#Check pcl_file_name
if [ ! -e $pcl_file_name ]
then
	echo "Error: file PCL dont exist. Please re-check How_to_run"
	echo "Example: gen_test_program.shsh Linux_SystemTest_Spec_RZG_latest.xls"
	exit 0
fi

#Convert xls to csv
mkdir tmp
list_sheet=`$xls2csv -x "$pcl_file_name" -W | egrep -v "Now reading|The following|Proposa|Q&A" | egrep -w -v "History"` 
for sheet in `echo $list_sheet`
do
	$xls2csv -x "$pcl_file_name" -w "$sheet" -c "tmp/$sheet.csv" > /dev/null
done

#Find column info of all input & output value
for sheet in `echo $list_sheet`
do
	all_val=`egrep Details_description tmp/$sheet.csv | sed -e 's/,/\n/g'`
	input_result_val=`egrep Details_description tmp/$sheet.csv | sed -e 's/,/\n/g' | egrep "input_|expected_value|config_tc|restore_tc|Details_description|Target_BSP|Call_sequence|File_name|output_of"`
	rm -rf tmp/.tmp_column_info_$sheet
	touch tmp/.tmp_column_info_$sheet
	for val in `echo $input_result_val`
	do
		a="0"
		for item in `echo $all_val`
		do
			a=`expr $a + 1`
			if [ `echo $item` = "$val" ]
			then
				echo "$val $a" >> tmp/.tmp_column_info_$sheet
			fi
		done
	done
done
 
##Make test program
rm -rf Test_program/
for sheet in `echo $list_sheet`
do
	rm -rf tmp/${sheet}_2.csv
	touch tmp/${sheet}_2.csv
	egrep -v "input_|Details_description" tmp/$sheet.csv | egrep -w "Autogen" >> tmp/${sheet}_2.csv
	total_line_of_pcl=`cat tmp/${sheet}_2.csv | wc -l`
	a=1
	while [ $a -le $total_line_of_pcl ]
	do
		Number=`sed -n ${a}p tmp/${sheet}_2.csv | awk -F'[,]' '{print $1}'`
		API_name=`sed -n ${a}p tmp/${sheet}_2.csv | awk -F'[,]' '{print $2}'`
		File_name=`sed -n ${a}p tmp/${sheet}_2.csv | awk -F'[,]' '{print $3}' | sed -e 's/\.c//g'`
		test_dir=${File_name}_"API"_${API_name}_${Number}
		test_program_sample=`cat sample/tc_name | egrep -w $test_dir | awk '{print $2}'`
		makefile_sample=`cat sample/tc_name | egrep -w $test_dir | awk '{print $3}'`
		name_in_sample=`cat sample/tc_name | egrep -w ${test_dir} | awk '{print $1}'`
		if [ $name_in_sample == $test_dir ]
		then
			mkdir -p Test_program/$test_dir
		else
			mkdir -p Test_program/${test_dir}_cant_find_in_tc_name
			echo "	Error: ${test_dir}_cant_find_in_tc_name"
			break
		fi
		echo "/*" > 			Test_program/$test_dir/test.c
		echo "* Project: CIP" >>	Test_program/$test_dir/test.c
		echo "* Test ID: $test_dir" >>	Test_program/$test_dir/test.c
		echo "* Feature: Checking $sheet API of file ${File_name}.c">> Test_program/$test_dir/test.c
		##Dev checking sheet name & api name
		echo "* Testing level: Unit Test" >>		Test_program/$test_dir/test.c
		echo "* Testing framework: Cmocka" >>		Test_program/$test_dir/test.c
		echo "* Test-case type: input_Type" >>		Test_program/$test_dir/test.c
		echo "* Expected result: expected_value" >>	Test_program/$test_dir/test.c
		echo "* Name: test.c" >>			Test_program/$test_dir/test.c
		echo "* Author: RVC/AnhTran (anh.tran.jc@rvc.renesas.com)" >> Test_program/$test_dir/test.c
		echo "* Version: v00r01" >>		Test_program/$test_dir/test.c
		echo "* Copyright: Renesas" >>		Test_program/$test_dir/test.c
		echo "* Target BSP: Target_BSP" >>	Test_program/$test_dir/test.c
		cp sample/$test_program_sample	Test_program/$test_dir/main_body.c
		cp sample/$makefile_sample		Test_program/$test_dir/Makefile

		b=1
		total_line_of_column_info=`cat ./tmp/.tmp_column_info_$sheet | wc -l`
		while [ $b -le $total_line_of_column_info ]
		do
			input_output_var=`sed -n ${b}p ./tmp/.tmp_column_info_$sheet | awk '{print $1}'`
			input_output_col=`sed -n ${b}p ./tmp/.tmp_column_info_$sheet | awk '{print $2}'`
			input_output_real=`sed -n ${a}p tmp/${sheet}_2.csv | awk -F'[,]' '{print $'$input_output_col'}' | sed -e 's/\"//g'`
			if [ "$input_output_var" == "Details_description" ]
			then
				echo "* Details_description: $input_output_real" >> Test_program/$test_dir/test.c
				echo "*/" >> Test_program/$test_dir/test.c
			else
				#echo "$input_output_var:	$input_output_real"
				cat	Test_program/$test_dir/test.c | sed -e s#$input_output_var#$input_output_real#g >> Test_program/$test_dir/main_tmp.c
				mv	Test_program/$test_dir/main_tmp.c Test_program/$test_dir/test.c
				cat	Test_program/$test_dir/main_body.c | sed -e s#$input_output_var#$input_output_real#g >> Test_program/$test_dir/main_tmp2.c
				mv	Test_program/$test_dir/main_tmp2.c Test_program/$test_dir/main_body.c
			fi
		b=`expr $b + 1`
		done

		cat Test_program/$test_dir/main_body.c >> Test_program/$test_dir/test.c
		rm -rf Test_program/$test_dir/main_body.c
		cp sample/GPL-COPYING		Test_program/$test_dir
		cp -rf src Test_program/
		cp -rf ../utility/00_compile_and_run_all.sh	Test_program/
		cp -rf ../utility/01_merge_all_coverage.sh	Test_program/
		
		echo "Making file: Test_program/$test_dir/test.c Done"
	a=`expr $a + 1`
	done
#	#dos2unix $test_dir/* >& /dev/null &
done
touch ./finish
rm -rf ./running
