#include <stdarg.h>
#include <stdint.h>
#include <stddef.h>
#include <setjmp.h>
#include <cmocka.h>
#include <errno.h>
#include "../src/s3ctl_private_dummy.h"
#include "../src/s3ctl_private.h"

static void test_s3ctl_init(void **state)
{
	int result;
	//output of map_register()
	will_return(__wrap_request_mem_region, 0);
	//will_return(__wrap_ioremap_nocache, 0);
	////will_return(__wrap_release_mem_region, 1);
	//will_return(__wrap_ioremap_nocache, 0);
	////product code
	//will_return(__wrap_ioread32, output_of_product);
	////es code
	//will_return(__wrap_ioread32, output_of_es);
	////set_xymodeconf
	//will_return(__wrap_writel, 0);
	////misc_register
	//will_return(__wrap_misc_register, 0);
	////spin_lock_init
	//will_return(__wrap_spin_lock_init, 0);
	
	//Run 	
	result = s3ctrl_init();
	//Check result
	assert_int_equal(result, expected_value);
}

int main(void)
{
	const struct CMUnitTest tests[] = {
	cmocka_unit_test(test_s3ctl_init)
	};

	return cmocka_run_group_tests(tests, NULL, NULL);
}
