#include <stdarg.h>
#include <stdint.h>
#include <stddef.h>
#include <setjmp.h>
#include <cmocka.h>
#include <errno.h>
#include "../src/s3ctl_private_dummy.h"
#include "../src/s3ctl_private.h"

static void test_open(void **state)
{
	int result;

	result = open(DEVFILE, O_RDWR);
	assert_int_equal(result, 0);
}

int main(void)
{
	const struct CMUnitTest tests[] = {
	cmocka_unit_test(test_open)
	};

	return cmocka_run_group_tests(tests, NULL, NULL);
}
