#include <stdarg.h>
#include <stdint.h>
#include <stddef.h>
#include <setjmp.h>
#include <cmocka.h>
#include "s3ctl_user_public.h"
#include "s3ctl_user_private.h"

int __wrap_open_dummy(const char *device_name, int mode_flags)
{
	return mock_type(int);
}

static void test_s3ctl_open(void **state)
{
	int result;
	S3CTL_ID pid;
	//will_return(__wrap_open_dummy, output_of_open);
	result = s3ctl_open(NULL);
	assert_int_equal(result, expected_value);
}

int main(void)
{
	const struct CMUnitTest tests[] = {
	cmocka_unit_test(test_s3ctl_open)
	};

	return cmocka_run_group_tests(tests, NULL, NULL);
}
