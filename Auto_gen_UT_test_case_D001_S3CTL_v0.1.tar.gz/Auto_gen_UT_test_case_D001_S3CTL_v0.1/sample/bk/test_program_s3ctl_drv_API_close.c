/*
* Project: CIP
* Test ID: s3ctl_drv_API_s3ctrl_init_01
* Feature: Checking s3ctrl_init API of file s3ctl_drv.c
* Testing level: Unit Test
* Testing framework: Cmocka
* Test-case type: Normal
* Expected result: 0
* Name: test.c
* Author: RVC/AnhTran (anh.tran.jc@rvc.renesas.com)
* Version: v00r01
* Copyright: Renesas
* Target BSP: CIP_iWaveG1M
* Details_description: Condition: Call s3ctl_clear_param with ioctl system_call = 0 and errno system = S3_PRR_H2. Expected result = 0
*/
#include <stdarg.h>
#include <stdint.h>
#include <stddef.h>
#include <setjmp.h>
#include <cmocka.h>
#include <errno.h>
#include "../src/s3ctl_private_dummy.h"
#include "../src/s3ctl_private.h"

//void __wrap_kzalloc(void)
//{
//        return mock_type(void);
//}

static void test_close(void **state)
{
	int result;

	//will_return(__wrap_request_mem_region, 1);
	//will_return(__wrap_ioremap_nocache, 1);
	//will_return(__wrap_ioremap_nocache, 1);
	//will_return(__wrap_ioread32, S3_PRR_H2);
	//will_return(__wrap_ioread32, S3_PRR_ES2);
	//will_return(__wrap_writel, 0);
	//will_return(__wrap_misc_register, 0);
	//will_return(__wrap_spin_lock_init, 0);
	////
	result = close(DEVFILE, O_RDWR);
	//assert_int_equal(result, 0);
}

int main(void)
{
	const struct CMUnitTest tests[] = {
	cmocka_unit_test(test_close)
	};

	return cmocka_run_group_tests(tests, NULL, NULL);
}
