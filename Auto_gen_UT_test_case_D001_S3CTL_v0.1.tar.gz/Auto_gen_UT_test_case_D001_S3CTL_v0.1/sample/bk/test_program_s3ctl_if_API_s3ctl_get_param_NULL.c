#include <stdarg.h>
#include <stdint.h>
#include <stddef.h>
#include <setjmp.h>
#include <cmocka.h>
#include <errno.h>
#include "s3ctl_user_public.h"
#include "s3ctl_user_private.h"

int __wrap_open_dummy(const char *device_name, int mode_flags)
{
        return mock_type(int);
}

int __wrap_ioctl(const char *device_name, int mode_flags)
{
	return mock_type(int);
}

static void test_s3ctl_get_param(void **state)
{
	int result;
	int id;
	struct S3_PARAM param;

	//will_return(__wrap_ioctl, output_of_ioctl);
	//errno = output_of_errno;
	
	result = s3ctl_get_param(id,NULL);
	assert_int_equal(result, expected_value);
}

int main(void)
{
	const struct CMUnitTest tests[] = {
	cmocka_unit_test(test_s3ctl_get_param)
	};

	return cmocka_run_group_tests(tests, NULL, NULL);
}
