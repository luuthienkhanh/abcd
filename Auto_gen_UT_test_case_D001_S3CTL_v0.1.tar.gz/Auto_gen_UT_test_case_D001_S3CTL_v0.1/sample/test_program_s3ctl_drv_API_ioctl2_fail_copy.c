#include <stdarg.h>
#include <stdint.h>
#include <stddef.h>
#include <setjmp.h>
#include <cmocka.h>
#include <errno.h>
#include "s3ctl_private_dummy.h"
#include "s3ctl_private.h"

void kzalloc(int num, int num2)
{
        malloc(num);
        return;
}

static void test_ioctl(void **state)
{
	int result;

	struct file *file_input;
	file_input = malloc(sizeof(struct file));

        struct S3_PRIVATE       *p2;
        p2 = malloc(sizeof(struct S3_PRIVATE));
        p2->id = -1;
        p2->st = input_state;
        file_input->private_data = p2;

	struct S3_PARAM param;
        param.phy_addr = input_phy_addr;
        param.stride = input_stride;
        param.area = input_area;


	//open_dummy(O_RDWR, file_input);
	will_return(__wrap_copy_from_user, 1);
	result = ioctl(file_input, input_cmd, &param);
	assert_int_equal(result, expected_value);
}

int main(void)
{
	const struct CMUnitTest tests[] = {
	cmocka_unit_test(test_ioctl)
	};

	return cmocka_run_group_tests(tests, NULL, NULL);
}
