#include <stdarg.h>
#include <stdint.h>
#include <stddef.h>
#include <setjmp.h>
#include <cmocka.h>
#include <errno.h>
#include "s3ctl_private_dummy.h"
#include "s3ctl_private.h"

static void test_s3ctl_exit(void **state)
{
	int result;
        will_return(__wrap_request_mem_region, 1);
        will_return(__wrap_ioremap_nocache, 0);
        will_return(__wrap_release_mem_region, 1);
        //will_return(__wrap_ioremap_nocache, 0);
        //will_return(__wrap_ioread32, S3_PRR_H2);
        //will_return(__wrap_ioread32, S3_PRR_ES2);
        //will_return(__wrap_writel, 0);
        //will_return(__wrap_misc_register, 0);
        //will_return(__wrap_spin_lock_init, 0);
        //
        result = s3ctrl_init();


	will_return(__wrap_misc_deregister, 0);
	//will_return(__wrap_iounmap, 0);
	//will_return(__wrap_release_mem_region, 1);
	//will_return(__wrap_iounmap, 0);
	
	s3ctrl_exit();
	//assert_int_equal(result, 0);
}

int main(void)
{
	const struct CMUnitTest tests[] = {
	cmocka_unit_test(test_s3ctl_exit)
	};

	return cmocka_run_group_tests(tests, NULL, NULL);
}
