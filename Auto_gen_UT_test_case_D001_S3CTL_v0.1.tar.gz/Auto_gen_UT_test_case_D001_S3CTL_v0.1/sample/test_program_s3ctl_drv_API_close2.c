#include <stdarg.h>
#include <stdint.h>
#include <stddef.h>
#include <setjmp.h>
#include <cmocka.h>
#include <errno.h>
#include "s3ctl_private_dummy.h"
#include "s3ctl_private.h"

void kzalloc(int num, int num2)
{
        malloc(num);
        return;
}

static void test_open(void **state)
{
	int result;

	struct file *file_input;
	file_input = malloc(sizeof(struct file));

        struct S3_PRIVATE       *p2;
        p2 = malloc(sizeof(struct S3_PRIVATE));
        p2->id = 1;
        p2->st = S3_ST_OPEN;
        file_input->private_data = p2;

	//open_dummy(O_RDWR, file_input);
	will_return(__wrap_writel, 0);
	will_return(__wrap_writel, 0);
	will_return(__wrap_spin_lock, 0);
	will_return(__wrap_spin_unlock, 0);
	will_return(__wrap_kfree, 0);
	close(O_RDWR, file_input);
	//assert_int_equal(result, 0);
}

int main(void)
{
	const struct CMUnitTest tests[] = {
	cmocka_unit_test(test_open)
	};

	return cmocka_run_group_tests(tests, NULL, NULL);
}
