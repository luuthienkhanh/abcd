#include <stdarg.h>
#include <stdint.h>
#include <stddef.h>
#include <setjmp.h>
#include <cmocka.h>
#include <errno.h>
#include "s3ctl_private_dummy.h"
#include "s3ctl_private.h"

void kzalloc(int num, int num2)
{
        malloc(num);
        return;
}

static void test_open(void **state)
{
	int result;
	struct file *file_input;
	file_input = malloc(sizeof(struct file));
	result = open_dummy(O_RDWR, file_input);
	assert_int_equal(result, 0);
}

int main(void)
{
	const struct CMUnitTest tests[] = {
	cmocka_unit_test(test_open)
	};

	return cmocka_run_group_tests(tests, NULL, NULL);
}
