#!/bin/csh -f
#Function: Cross compile all UT Test Program
#Author: AnhT 
#Version: 0.1
#Project: CIP
#Note: This tool run on Linux PC with Cmocka test framework

clear
#=================Input_seting===============#
setenv current_dir `pwd`

#=================Compile_all===============#
echo "" >! coverage_merged.info
set list_source = `egrep "^MAIN_SRC" */Makefile  | awk '{print $NF}' | sort -u | awk -F'/' '{print $NF}'`
foreach source_file ($list_source)
	#echo $source_file
	set list_dir = `egrep $source_file */Makefile | egrep "Makefile:MAIN_SRC" | awk -F'/' '{print $1}'`
	set file_name = `echo $source_file | awk -F'.' '{print $1}'`
	set first_report = `ls */*/*.gcda | egrep -w "$file_name.gcda" | sed -n '1p' | awk -F'/' '{print $1}'`
	lcov -d $first_report/obj -c -i -o coverage_merged_$file_name.info
	cat coverage_merged_$file_name.info >> coverage_merged.info
	rm -rf coverage_merged_$file_name.info
end
#lcov -d s3ctl_if_API_s3ctl_clear_param_01/obj -d s3ctl_drv_API_s3ctrl_exit_01/obj -c -i -o coverage_merged.info
#
set list_tc = `ls */obj/*.gcda | awk -F'/' '{print $1}'`
foreach TC (`echo $list_tc`)
	lcov -a $TC/obj/coverage.info -a coverage_merged.info -o coverage_merged.info
end

genhtml coverage_merged.info -o coverage_summary_html

echo ""
echo "Finish merge all coverage report. Output: coverage_summary_html/index.html"
echo "Open command: firefox coverage_summary_html/index.html"

