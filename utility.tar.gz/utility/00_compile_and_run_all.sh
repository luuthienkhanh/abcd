#!/bin/csh -f
#Function: Cross compile all UT Test Program
#Author: AnhT 
#Version: 0.1
#Project: CIP
#Note: This tool run on Linux PC with Cmocka test framework

clear
#=================Input_seting===============#
setenv current_dir `pwd`

#=================Compile_all_and_run===============#
set list_tc = `ls -l | egrep "^d" | awk '{print $NF}' | egrep -v "src|.csh|coverage_"`
foreach TC (`echo $list_tc`)
	echo ""
	echo $current_dir/$TC
	cd $current_dir/$TC
	make clean
	make	
	cd $current_dir/
end

cd $current_dir
echo "Below Test Program don't have ERROR:" >! log_run_all
egrep ERROR */*log | awk -F':' '{print $1}' >> log_run_all
#ls */obj/*.gcda	| awk -F'/' '{print $1}' | sort -u > list_gcda
#ls */obj/*.gcno	| awk -F'/' '{print $1}' | sort -u > list_gcno
#if (`diff list_gcno list_gcda | wc -l`) then
#	diff list_gcno list_gcda | egrep "<" | awk '{print $NF}' >> log_run_all
#endif
#rm -rf list_gcda list_gcno	
